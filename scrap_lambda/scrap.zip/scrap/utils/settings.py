from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

class Settings(BaseSettings):
    model_config=SettingsConfigDict(
        env_file=".env",
        env_file_encoding='utf-8'
    )
    TABLE_NAME: Optional[str] = None
    PROCESS: str

settings=Settings()