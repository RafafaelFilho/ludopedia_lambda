from boto3.dynamodb.conditions  import Key
from scrap.utils.settings      import settings
import boto3
import os
import uuid

def connect_database():
    dynamodb=boto3.resource('dynamodb', region_name='us-east-1')
    table=dynamodb.Table(settings.TABLE_NAME)
    return table

def download_active_auctions(table):
    response = table.query(
        IndexName='StatusIndex',
        KeyConditionExpression=Key('status').eq('em andamento')
    )
    return response

def download_games(table):
    response = table.query(
        IndexName='TipoRegistroIndex',
        KeyConditionExpression=Key('tipo_registro').eq('jogo')
    )
    return response

def download_auction(table, pk, sk):
    response=table.get_item(
        Key={
            'PK':pk,
            'SK':sk
        }
    )
    return response

def auction_exists(table, pk, sk):
    download_auction(table, pk, sk)

def register_data(table, data_list):
    for data in data_list:
        table.put_item(Item=data)

def registry_update(table, info, register):
    update_expressions = []
    expression_values = {}
    expression_names = {}

    for i, (campo, valor) in enumerate(info.items()):
        placeholder = f":val{i}"
        name_placeholder = f"#field{i}"
        update_expressions.append(f"{name_placeholder} = {placeholder}")
        
        expression_names[name_placeholder] = campo
        expression_values[placeholder] = valor

    response=table.update_item(
        Key={'PK': register['PK'], 'SK': register['SK']},
        UpdateExpression='SET ' + ', '.join(update_expressions),
        ExpressionAttributeValues=expression_values,
        ExpressionAttributeNames=expression_names
    )
    return response