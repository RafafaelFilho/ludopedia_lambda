from scrap.core.search_auctions import SearchAuctions
from scrap.core.update_auctions import UpdateAuctions
from scrap.utils.settings import settings
import json

def lambda_handler(event, context):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115 Safari/537.36'}
    if settings.PROCESS=='searcher':
        SearchAuctions(headers).run()
        print('processo rodou')
    elif settings.PROCESS=='updater':
        UpdateAuctions(headers).run()
    else:
        print('mock funcionou')
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
