from scrap.models.database import connect_database, download_games, register_data
from scrap.core.scraper import get_trs, parse_tr_to_auction

class SearchAuctions:
    def __init__(self, headers):
        self.headers=headers
        self.engine=None
        self.games=[]
        self.new_auctions=[]

    def run(self):
        self.connect_to_db()
        self.load_games()
        self.scrape_auctions()
        self.save_new_auctions()

    def connect_to_db(self):
        self.engine=connect_database()

    def load_games(self):
        self.games=download_games(self.engine)

    def scrape_auctions(self):
        for game in self.games.get('Items'):
            trs=get_trs(game, self.headers)
            if not trs:
                continue
            for tr in trs:
                auction_data=parse_tr_to_auction(tr, game, self.engine)
                if auction_data:
                    self.new_auctions.append(auction_data)
                    
    def save_new_auctions(self):
        if self.new_auctions:
            register_data(self.engine, self.new_auctions)
        
